const isSupported = require('../../lib/gzip/isSupported');

describe('gzip isSupported', () => {
    test('returns false when no accept-encoding header is present', () => {
        const response = {
            headers: {},
        };
        expect(isSupported(response)).toBe(false);
    });

    test('returns false when accept-encoding does not contain gzip', () => {
        const response = {
            headers: {
                'accept-encoding': [{ value: 'deflate' }],
            },
        };
        expect(isSupported(response)).toBe(false);
    });

    test('returns true when accept-encoding contains gzip', () => {
        const response = {
            headers: {
                'accept-encoding': [{ value: 'gzip' }, { value: 'deflate' }],
            },
        };
        expect(isSupported(response)).toBe(true);
    });
});
